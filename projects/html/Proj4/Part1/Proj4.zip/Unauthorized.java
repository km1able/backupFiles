import java.io.*;

public class Unauthorized {
    public static void main(String args[]) throws Exception {

        String storedValue = "Gilgamesh";
        System.out.println("This user has accessed this program- no authorization required!");
        System.out.println("Stored value is: " + storedValue);
    }
}
